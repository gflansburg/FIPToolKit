module("OutputType", package.seeall)

--- @enum OutputType
local OutputType = {
	integer = "integer",
	string = "string",
}

return OutputType
