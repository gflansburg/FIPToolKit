module("ActionArgument", package.seeall)

--- @enum ActionArgument
local ActionArgument = {
	toggle = "TOGGLE",
	toggle_xy = "TOGGLE_XY",
}

return ActionArgument
