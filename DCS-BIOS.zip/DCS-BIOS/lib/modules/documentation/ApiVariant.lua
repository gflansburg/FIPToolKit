module("ApiVariant", package.seeall)

--- @enum ApiVariant
local ApiVariant = {
	momentary_last_position = "momentary_last_position",
	multiturn = "multiturn",
}

return ApiVariant
