module("CommonData", package.seeall)

local AircraftList = require("Scripts.DCS-BIOS.lib.AircraftList")

local Module = require("Scripts.DCS-BIOS.lib.modules.Module")

--- @class CommonData: Module
local CommonData = Module:new("CommonData", 0x0400, AircraftList.ALL_PLAYABLE_AIRCRAFT)
CommonData.dev0_required = false

local lat = 0
local latDeg = 0
local latSec = 0
local latFractionalSec = 0
local lon = 0
local lonDeg = 0
local lonSec = 0
local lonFractionalSec = 0
local altFt = 0
local aglFt = 0
local hdgDeg = 0
local hdgDegFrac = 0
local adfAvailable = false
local rmiAvailable = false
local adf = 0
local rmi = 0
local course = 0
local courseTrue = 0;
local heading = 0
local headingPointer = 0
local bearingPointer = 0
local courseDeviation = 0
local windDirection = 0
local windSpeed = 0
local temperatureCelsius = 0

local latDir = "N"
local lonDir = "E"

local angular_velocity_x = "0"
local angular_velocity_y = "0"
local angular_velocity_z = "0"
local angular_max_length = 6

local function getTemperatureAtPoint(point)
    return LoGetTemperatureAtPoint(point)
end


local function safeGetTemperature(point)
    local success, result = pcall(getTemperatureAtPoint, point)
    if not success then
        return nil
    end
    return result
end

local function updatePosition()
	if not LoIsOwnshipExportAllowed() then
		return
	end -- skip this data if ownship export is disabled

	altFt = math.floor(LoGetAltitudeAboveSeaLevel() * 3.28084)
	aglFt = math.floor(LoGetAltitudeAboveGroundLevel() * 3.28084)

	local HSI = LoGetControlPanel_HSI()
	if HSI ~= nil then
		adfAvailable = HSI.ADF_raw == nil and false or true
		rmiAvailable = HSI.RMI_raw == nil and false or true
		adf = HSI.ADF_raw == nil and 0 or HSI.ADF_raw
		rmi = HSI.RMI_raw == nil and 0 or HSI.RMI_raw
		heading = HSI.Heading_raw and 0 or HSI.Heading_raw
		course = HSI.Course and 0 or HSI.Course
		headingPointer = HSI.HeadingPointer and 0 or HSI.HeadingPointer
		bearingPointer = HSI.BearingPointer and 0 or HSI.BearingPointer
		courseDeviation = HSI.CourseDeviation and 0 or HSI.CourseDeviation
	end

	local selfData = LoGetSelfData()
	if selfData == nil then
		return
	end

    courseTrue = course + (selfData.MagneticDeclination or 0)

	local vx,vy,vz = LoGetWindAtPoint({
        x = selfData.Position.x,
        y = selfData.Position.y,
        z = selfData.Position.z
    })
	if vx and vz then
		windDirection = math.atan2(-vz,-vx);
	end
	if (vx and vy and vz) then
		windSpeed = math.sqrt(vx^2 + vy^2 + vz^2)
	end

    local point = {x = selfData.Position.x, y = selfData.Position.y, z = selfData.Position.z}
	local temperatureKelvin = safeGetTemperature(point)
    if temperatureKelvin then
        -- Convert to Celsius
        temperatureCelsius = temperatureKelvin - 273.15
    end
	
	if selfData.LatLongAlt == nil then
		return
	end

	lat = selfData.LatLongAlt.Lat
	if lat < 0 then
		lat = 0 - lat
		latDir = "S"
	else
		lat = lat
		latDir = "N"
	end
	lon = selfData.LatLongAlt.Long
	if lon < 0 then
		lon = 0 - lon
		lonDir = "W"
	else
		lon = lon
		lonDir = "E"
	end

	latDeg = math.floor(lat)
	local lat1 = (lat - latDeg) * 60 -- to sec
	latSec = math.floor(lat1)
	latFractionalSec = math.floor((lat1 - latSec) * 65535)

	lonDeg = math.floor(lon)
	local lon1 = (lon - lonDeg) * 60 -- to sec
	lonSec = math.floor(lon1)
	lonFractionalSec = math.floor((lon1 - lonSec) * 65535)

	if selfData.Heading ~= nil then
		local hdgDegValue = selfData.Heading / (2 * math.pi) * 360
		hdgDeg = math.floor(hdgDegValue)
		hdgDegFrac = (hdgDegValue - hdgDeg) * 127
	end
end
CommonData:addExportHook(updatePosition)

local function getVersion()
	return "0.8.3"
end
CommonData:defineString("DCS_BIOS", getVersion, 6, "Metadata", "DCS Bios Version")

local function getPlayerName()
	if not LoIsOwnshipExportAllowed() then
		return "XXX"
	end -- skip this data if ownship export is disabled

	return LoGetPilotName() or "XXX"
end

CommonData:defineString("PILOTNAME", getPlayerName, 24, "Metadata", "Pilot Name")

CommonData:defineString("LAT_Z_DIR", function()
	return latDir
end, 1, "Position", "Latitude Direction")
CommonData:defineIntegerFromGetter("LAT_DEG", function()
	return latDeg
end, 90, "Position", "Latitude Degrees")
CommonData:defineIntegerFromGetter("LAT_SEC", function()
	return latSec
end, 59, "Position", "Latitude Seconds")
CommonData:defineIntegerFromGetter("LAT_SEC_FRAC", function()
	return latFractionalSec
end, 65535, "Position", "Latitude Fractional Seconds (divide by 65535)")

local iasKph = 0
local iasKt = 0
local iasEU = ""
local iasUS = ""

local tasKph = 0
local tasKt = 0
local tasEU = ""
local tasUS = ""

local function updateAirspeed()
	if not LoIsOwnshipExportAllowed() then
		return
	end -- skip this data if ownship export is disabled

	local iasDisp = LoGetIndicatedAirSpeed()

	if not iasDisp then
		return
	end
	iasKph = Module.round(iasDisp * 3.6)
	iasKt = Module.round(iasDisp * 1.94384449)

	iasEU = string.format("%4d", iasKph) -- km/h
	iasUS = string.format("%4d", iasKt) -- knots

	local tasDisp = LoGetTrueAirSpeed()
	if not tasDisp then
		return
	end
	tasKph = Module.round(tasDisp * 3.6)
	tasKt = Module.round(tasDisp * 1.94384449)

	tasEU = string.format("%4d", tasKph) -- km/h
	tasUS = string.format("%4d", tasKt) -- knots
end
CommonData:addExportHook(updateAirspeed)

CommonData:defineString("IAS_EU", function()
	return iasEU
end, 4, "Speed", "Indicated Airspeed KM H")
CommonData:defineString("IAS_US", function()
	return iasUS
end, 4, "Speed", "Indicated Airspeed KNT")
CommonData:defineIntegerFromGetter("IAS_EU_INT", function()
	return iasKph
end, 65535, "Speed", "Indicated Airspeed KM H (Int)")
CommonData:defineIntegerFromGetter("IAS_US_INT", function()
	return iasKt
end, 65535, "Speed", "Indicated Airspeed KNT (Int)")

CommonData:defineString("LON_Z_DIR", function()
	return lonDir
end, 1, "Position", "Longitude Direction")
CommonData:defineIntegerFromGetter("LON_DEG", function()
	return lonDeg
end, 180, "Position", "Longitude Degrees")
CommonData:defineIntegerFromGetter("LON_SEC", function()
	return lonSec
end, 59, "Position", "Longitude Seconds")
CommonData:defineIntegerFromGetter("LON_SEC_FRAC", function()
	return lonFractionalSec
end, 65535, "Position", "Longitude Fractional Seconds (divide by 65535)")

CommonData:defineIntegerFromGetter("ALT_MSL_FT", function()
	return altFt
end, 65535, "Altitude", "Altitude MSL (ft)")

CommonData:defineIntegerFromGetter("HDG_DEG", function()
	return hdgDeg
end, 360, "Heading", "Heading (Degrees)")
CommonData:defineIntegerFromGetter("HDG_DEG_FRAC", function()
	return hdgDegFrac
end, 127, "Heading", "Heading (Fractional Degrees, divide by 127)")

local missionStartTime = ""
local startTimeLow = 0
local startTimeHigh = 0

local function updateMissionTime()
	if not LoIsOwnshipExportAllowed() then
		return
	end -- skip this data if ownship export is disabled

	local startTime = LoGetMissionStartTime() or 0
	startTimeLow = startTime % 65536
	startTimeHigh = (startTime - startTimeLow) / 65536

	local mtseconds = tonumber(startTime)

	if mtseconds <= 0 then
		missionStartTime = "00:00:00"
	else
		local mtsec = string.format("%02.f", math.floor(mtseconds or 0))
		local mthours = string.format("%02.f", math.floor(mtseconds / 3600))
		local mtmins = string.format("%02.f", math.floor(mtseconds / 60 - (mthours * 60)))
		missionStartTime = mthours .. ":" .. mtmins .. ":" .. mtsec
	end
end
CommonData:addExportHook(updateMissionTime)

local modTime = "00000"
local modTimeLow = 0
local modTimeHigh = 0
local function updateModelTime()
	if not LoIsOwnshipExportAllowed() then
		return
	end -- skip this data if ownship export is disabled

	local modTimeFloat = LoGetModelTime() or 0
	modTime = string.format("%5.0f", modTimeFloat)
	local modTimeHundredth = math.floor(modTimeFloat * 100)
	modTimeLow = modTimeHundredth % 65536
	modTimeHigh = (modTimeHundredth - modTimeLow) / 65536
end
CommonData:addExportHook(updateModelTime)

CommonData:defineString("MISS_TIME", function()
	return missionStartTime
end, 8, "Time", "Mission Start Time")
CommonData:defineString("MOD_TIME", function()
	return modTime
end, 6, "Time", "Model Time in sec")

CommonData:defineIntegerFromGetter("TIME_START_HIGH", function()
	return startTimeHigh
end, 65535, "Time", "Start time high bits in seconds")
CommonData:defineIntegerFromGetter("TIME_START_LOW", function()
	return startTimeLow
end, 65535, "Time", "Start time low bits in seconds")
CommonData:defineIntegerFromGetter("TIME_MODEL_HIGH", function()
	return modTimeHigh
end, 65535, "Time", "Model time high bits in hundredth of a second")
CommonData:defineIntegerFromGetter("TIME_MODEL_LOW", function()
	return modTimeLow
end, 65535, "Time", "Model time low bits in hundredth of a second")

local function LoGetGLoad()
	local au = LoGetAccelerationUnits()
	if au == nil then
		return
	end
	return au.y
end

local function getGLoad()
	if not LoIsOwnshipExportAllowed() then
		return ""
	end -- skip this data if ownship export is disabled

	local gload = LoGetGLoad() or 0

	if math.abs(gload) > 10 then
		return string.format(" %2d ", gload)
	end

	return string.format("%4.1f", gload)
end

CommonData:defineString("G_LOAD", getGLoad, 4, "Speed", "G Load")

CommonData:addExportHook(function()
	if not LoIsOwnshipExportAllowed() then
		return
	end -- skip this data if ownship export is disabled

	local angular_velocity = LoGetAngularVelocity()
	if angular_velocity == nil then
		return
	end

	angular_velocity_x = tostring(angular_velocity.x)
	angular_velocity_y = tostring(angular_velocity.y)
	angular_velocity_z = tostring(angular_velocity.z)
end)

CommonData:defineString("ANGULAR_VELOCITY_X", function()
	return angular_velocity_x
end, angular_max_length, "Speed", "Angular X Velocity")

CommonData:defineString("ANGULAR_VELOCITY_Y", function()
	return angular_velocity_y
end, angular_max_length, "Speed", "Angular Y Velocity")

CommonData:defineString("ANGULAR_VELOCITY_Z", function()
	return angular_velocity_z
end, angular_max_length, "Speed", "Angular Z Velocity")

CommonData:defineIntegerFromGetter("HDG_DEG_MAG", function()
	local magnetic_heading_rad = LoGetMagneticYaw()
	local heading = Module.round(magnetic_heading_rad * 180 / math.pi) % 360
	if heading < 0 then -- you'd think this would always be positive, but sometimes radians is negative!
		heading = heading + 360
	end
	return heading
end, 359, "Heading", "Magnetic Heading")

local function doubleToString(doubleValue)
    return string.format("%.17g", doubleValue)
end

CommonData:defineIntegerFromGetter("ALT_AGL_FT", function()
	return aglFt
end, 65535, "Altitude", "Altitude AGL (ft)")

CommonData:defineString("TAS_EU", function()
	return tasEU
end, 4, "Speed", "True Airspeed KM H")

CommonData:defineString("TAS_US", function()
	return tasUS
end, 4, "Speed", "True Airspeed KNT")

CommonData:defineIntegerFromGetter("TAS_EU_INT", function()
	return tasKph
end, 65535, "Speed", "True Airspeed KM H (Int)")

CommonData:defineIntegerFromGetter("TAS_US_INT", function()
	return tasKt
end, 65535, "Speed", "True Airspeed KNT (Int)")

CommonData:defineString("KOHLSMAN", function()
	local pressure = LoGetBasicAtmospherePressure() or 759.96801
	return doubleToString(pressure)
end, 24, "Metadata", "Atmosphere Pressure (mmHg)")

CommonData:defineString("WIND_DIR_RAD", function()
	return doubleToString(windDirection)
end, 24, "Metadata", "Wind Direction (Radians)")

CommonData:defineString("WIND_DIR_DEG", function()
	local direction = windDirection * (180 / math.pi)
	if direction < 0 then -- you'd think this would always be positive, but sometimes radians is negative!
		direction = direction + 360
	end
	return doubleToString(direction)
end, 24, "Metadata", "Wind Direction (Degrees)")

CommonData:defineString("WIND_SPEED", function()
	return doubleToString(windSpeed)
end, 24, "Metadata", "Wind Speed (m/sec)")

CommonData:defineString("LATITUDE", function()
	return doubleToString(lat)
end, 24, "Position", "Latitude")

CommonData:defineString("LONGITUDE", function()
	return doubleToString(lon)
end, 24, "Position", "Longitude")

CommonData:defineString("POSITION", function()
	return string.format("%.17g,%.17g", lat, lon)
end, 49, "Position", "Latitude and Longitude")

CommonData:defineString("ADF_RAD", function()
	return doubleToString(adf)
end, 24, "Metadata", "Automatic Direction Finder (Radians)")

CommonData:defineString("RMI_RAD", function()
	return doubleToString(rmi)
end, 24, "Metadata", "Radio Magnetic Indicator (Radians)")

CommonData:defineString("COURSE_RAD", function()
	return doubleToString(course)
end, 24, "Metadata", "Course Magnetic (Radians)")

CommonData:defineString("COURSE_TRUE_RAD", function()
	return doubleToString(courseTrue)
end, 24, "Metadata", "Course True (Radians)")

CommonData:defineString("HDG_PNT_RAD", function()
	return doubleToString(headingPointer)
end, 24, "Heading", "Heading Pointer (Radians)")

CommonData:defineString("BRG_PNT_RAD", function()
	return doubleToString(bearingPointer)
end, 24, "Heading", "Bearing Pointer (Radians)")

CommonData:defineString("HDG_RAD", function()
	return doubleToString(heading)
end, 24, "Heading", "Heading (Radians)")

CommonData:defineString("CRS_DEV_RAD", function()
	return doubleToString(courseDeviation)
end, 24, "Metadata", "Course Deviation (Radians)")

CommonData:defineString("CRS_TRK_ERR", function()
	return doubleToString(calculate_cross_track_error())
end, 24, "Metadata", "Cross Track Error (Meters)")

CommonData:defineString("TEMPERATURE", function()
	return doubleToString(temperatureCelsius)
end, 24, "Metadata", "Ambient Temperature (Celcius)")

CommonData:defineIntegerFromGetter("ACTIVE_WP", function()
	return hasActiveWaypoint() and 1 or 0
end, 1, "Metadata", "Has an active waypoint")

CommonData:defineIntegerFromGetter("ADF_AVAIL", function()
	return adfAvailable and 1 or 0
end, 1, "Metadata", "Is ADF available?")

CommonData:defineIntegerFromGetter("RMI_AVAIL", function()
	return rmiAvailable and 1 or 0
end, 1, "Metadata", "Is RMI available?")

CommonData:defineIntegerFromGetter("ON_GROUND", function()
	return isAircraftOnGround() and 1 or 0
end, 1, "Metadata", "Is aircraft on the ground or not?")

CommonData:defineIntegerFromGetter("IS_HELICOPTER", function()
	return isHelicopter() and 1 or 0
end, 1, "Metadata", "Is helicopter or fixed-wing?")

CommonData:defineString("ENGINE_TYPE", function()
	return getEngineType()
end, 10, "Metadata", "Engine Type (Jet, Piston, Turboprop, Unknown)")

CommonData:defineString("GRNDS_US", function()
	return string.format("%4d", getGroundSpeedInKnots())
end, 4, "Speed", "Ground Speed KNT")

CommonData:defineString("GRNDS_EU", function()
	return string.format("%4d", getGroundSpeedInKMH())
end, 4, "Speed", "Ground Speed KM H")

function calculate_cross_track_error()
	
	if not LoIsOwnshipExportAllowed() then
        return nil -- Skip if ownship export is disabled
    end
	
    local R = 6371000 -- Earth's radius in meters

    -- Helper function to convert degrees to radians
    local function toRadians(deg) return deg * math.pi / 180 end

    -- Get aircraft position and heading
    local selfData = LoGetSelfData()
    if selfData == nil then 
		return nil 
	end
    
	local lat1 = toRadians(selfData.LatLongAlt.Lat)
    local lon1 = toRadians(selfData.LatLongAlt.Long)

    -- Get current waypoint position
    local route = LoGetRoute()
    if route == nil or route[1] == nil then 
		return nil 
	end
	
    local currentWaypoint = route[1]
    local lat2 = toRadians(currentWaypoint.latitude)
    local lon2 = toRadians(currentWaypoint.longitude)
    local course_bearing = toRadians(currentWaypoint.course) -- Desired course in radians

    -- Haversine formula for great-circle distance
    local deltaLat = lat2 - lat1
    local deltaLon = lon2 - lon1
    local a = math.sin(deltaLat / 2)^2 + math.cos(lat1) * math.cos(lat2) * math.sin(deltaLon / 2)^2
    local c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    local distance_to_waypoint = R * c

    -- Bearing to waypoint
    local y = math.sin(deltaLon) * math.cos(lat2)
    local x = math.cos(lat1) * math.sin(lat2) - math.sin(lat1) * math.cos(lat2) * math.cos(deltaLon)
    local bearing_to_waypoint = math.atan2(y, x)

    -- Angular difference
    local angular_difference = bearing_to_waypoint - course_bearing

    -- Cross-Track Error
    local cross_track_error = distance_to_waypoint * math.sin(angular_difference)
    return cross_track_error -- In meters
end

function hasActiveWaypoint()
	if not LoIsOwnshipExportAllowed() then
        return false -- Skip if ownship export is disabled
    end

    local route = LoGetRoute() -- Get the current route
    if route and route[1] then
        return true -- There is an active waypoint
    else
        return false -- No active waypoint
    end
end

function isAircraftOnGround()
	if not LoIsOwnshipExportAllowed() then
        return false -- Skip if ownship export is disabled
    end

    local mechInfo = LoGetMechInfo()
    if mechInfo and mechInfo.gear and mechInfo.gear.main and mechInfo.gear.main.wow then
        return mechInfo.gear.main.wow > 0 -- Returns true if the main gear has weight on wheels
    end
    return false
end

function isHelicopter()
	if not LoIsOwnshipExportAllowed() then
        return false -- Skip if ownship export is disabled
    end

    local selfData = LoGetSelfData()

    -- Check by name (common for LoGetSelfData)
    if selfData and selfData.Name then
        local name = selfData.Name:lower()
        if name:find("ka-") or name:find("mi-") or name:find("uh-") then
            return true
        end
    end

    -- Check by type category (if available)
    if selfData and selfData.Type and selfData.Type.category then
        return selfData.Type.category == 1 -- Helicopters are category 1
    end

    return false -- Default to fixed-wing if no match
end

function getEngineTypeByName()
	if not LoIsOwnshipExportAllowed() then
        return "Unknown" -- Skip if ownship export is disabled
    end

    local selfData = LoGetSelfData()
    if selfData and selfData.Name then
        local name = selfData.Name:lower()
        if name:find("f-") or name:find("mig-") or name:find("su-") then
            return "Jet"
        elseif name:find("p-") or name:find("bf-") or name:find("fw-") then
            return "Piston"
        elseif name:find("c-") or name:find("an-") then
            return "Turboprop"
        end
    end
    return "Unknown"
end

function getEngineTypeByPerformance()
	if not LoIsOwnshipExportAllowed() then
        return "Unknown" -- Skip if ownship export is disabled
    end

    local engineInfo = LoGetEngineInfo()
    if engineInfo then
        if engineInfo.THRUST_L or engineInfo.THRUST_R then
            return "Jet" -- Presence of thrust indicates jet
        elseif engineInfo.RPM[1] and engineInfo.RPM[1] > 3000 then
            return "Piston" -- High RPM is typical for piston engines
        elseif engineInfo.RPM[1] and engineInfo.RPM[1] < 3000 then
            return "Turboprop" -- Lower RPM may indicate a turboprop
        end
    end
    return "Unknown"
end

function getEngineTypeByCategory()
	if not LoIsOwnshipExportAllowed() then
        return "Unknown" -- Skip if ownship export is disabled
    end

    local selfData = LoGetSelfData()
    if selfData and selfData.Type then
        local category = selfData.Type.category
        if category == 0 then
            return "Jet" -- Most fixed-wing aircraft are jets
        elseif category == 1 then
            return "Piston or Helicopter" -- Helicopters or prop planes
        end
    end
    return "Unknown"
end

function getEngineType()
    -- Try to infer from name
    local engineType = getEngineTypeByName()
    if engineType ~= "Unknown" then
        return engineType
    end

    -- Try to infer from engine performance
    engineType = getEngineTypeByPerformance()
    if engineType ~= "Unknown" then
        return engineType
    end

    -- Try to infer from category
    return getEngineTypeByCategory()
end

function getGroundSpeed()
	if not LoIsOwnshipExportAllowed() then
        return nil -- Skip if ownship export is disabled
    end

    local selfData = LoGetSelfData()
    if selfData then
        local vx = selfData.Vx -- Velocity along the X-axis
        local vz = selfData.Vz -- Velocity along the Z-axis
        return math.sqrt(vx^2 + vz^2) -- Ground speed in meters per second
    end
    return nil -- Data not available
end

function getGroundSpeedInKnots()
    local groundSpeed = getGroundSpeed()
    if groundSpeed then
        return groundSpeed * 1.94384 -- Convert m/s to knots
    end
    return nil
end

function getGroundSpeedInKMH()
    local groundSpeed = getGroundSpeed()
    if groundSpeed then
        return groundSpeed * 3.6 -- Convert m/s to km/h
    end
    return nil
end

return CommonData
